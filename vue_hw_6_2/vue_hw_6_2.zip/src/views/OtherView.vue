<script setup>

</script>

<template>
    <div>
        <h1>이동한 페이지</h1>
    </div>
</template>

<style scoped>

</style>
