<script setup>

</script>

<template>
    <div>
        <h1>첫 페이지</h1>
    </div>
</template>

<style scoped>

</style>
