<script setup>

</script>

<template>
    <div>
      <h1>router 연습하기</h1>
    </div>
  </template>

<style scoped>

</style>